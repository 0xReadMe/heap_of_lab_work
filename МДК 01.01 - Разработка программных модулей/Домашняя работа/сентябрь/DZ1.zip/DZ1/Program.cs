﻿using System;

namespace DZ1
{
    class Program
    {
        static void Main(string[] args)
        {
            Car car = new();
            Car car1 = new Car(1000, "A123BC", 58, "blue");

            var weightCar = car1.weight;
            var numCar = car1.numberCar;

            // private field
            // var weightEngineCar = car1.weightEngine;

            // protected field
            // var colorCar = car1.color;

            Console.WriteLine($"Полученная информация о созданном автомобиле - {weightCar} | {numCar}");
        }
    }
}
