﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ1
{
    class Car
    {
        internal int weight;
        public string numberCar;
        private int weightEngine;
        protected string color;

        public Car() 
        {
            Console.WriteLine($"Вы создали пустой автомобиль.");
        }

        public Car(int weight, string numberCar, int weightEngine, string color)
        {
            this.weight = weight;
            this.numberCar = numberCar;
            this.weightEngine = weightEngine;
            this.color = color;
            Console.WriteLine($"Записали данные о весе автомобиля - {weight}.");
            Console.WriteLine($"Записали данные о номере автомобиля - {numberCar}.");
            Console.WriteLine($"Записали данные о весе двигателя автомобиля - {weightEngine}.");
            Console.WriteLine($"Записали данные о цвете автомобиля - {color}.");
        }
    }
}
